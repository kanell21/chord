package chord;

import java.io.Serializable;
import java.util.Hashtable;

public class Message implements Serializable {

	private static final long serialVersionUID = 1L;
	private int to;
	private int from;
	private int replyTo;
	private String body;
	private int hashKey;
	private Hashtable<Integer,String> hashtable;
	private Type type;

	public Message() {}
	
	public Message(int to, int from, int replyTo, String body, int hashKey, Hashtable<Integer,String> hashtable, Type type) {

		this.to = to;
		this.from = from;
		this.replyTo = replyTo;
		this.body = body;
		this.hashKey = hashKey;
		this.hashtable = hashtable;
		this.type = type;
	}

	public void setTo(int to) {
		this.to = to;
	}
	public void setFrom(int from) {
		this.from = from;
	}
	public void setReplyTo(int replyTo) {
		this.replyTo = replyTo;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public void setHashKey(int hashKey) {
		this.hashKey = hashKey;
	}
	public void setHashtable(Hashtable<Integer,String> hashtable) {
		this.hashtable = hashtable;
	}
	public void setType(Type type) {
		this.type = type;
	}
	public int getTo() {
		return this.to;
	}
	public int getFrom() {
		return this.from;
	}
	public int getReplyTo() {
		return this.replyTo;
	}
	public String getBody() {
		return this.body;
	}
	public int getHashKey() {
		return this.hashKey;
	}
	public Hashtable<Integer,String> getHashtable() {
		return this.hashtable;
	}
	public Type getType() {
		return this.type;
	}

}
