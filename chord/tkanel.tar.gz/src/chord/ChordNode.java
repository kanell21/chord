package chord;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;


public class ChordNode extends Thread {
	
	public Hashtable<Integer, String> hashtable;
	public ServerSocket Server;
    public int id;
    public int number;
    public int predecessor;
    public int successor;
    public int PORT = 49152;
    public String IPV4 = "127.0.0.1";
    public boolean alive = true;
    
    private class PredSucc {
    	int predecessor;
    	int successor;
    }
    
    public ChordNode(int id, int number) {
        this.id = id;
        this.number = number;
    }
    
    
    
    @Override
    public void run(){
        try {
            Server = new ServerSocket(PORT + this.id);
            System.out.println(this.id + "\t: Started my Server using port " + Server.getLocalPort());
            PredSucc predsucc;
            if (this.id > 0)
            	predsucc = FindPredSucc();
            else {
            	predsucc = new PredSucc();
            	predsucc.predecessor = 0;
            	predsucc.successor = 0;
            }
            this.predecessor = predsucc.predecessor;
            this.successor = predsucc.successor;
            
            if (this.predecessor != this.id) {
            	Message succInform = new Message(this.predecessor, this.id, -1, Integer.toString(this.id), -1, null, Type.NEW_SUCC_INFORM);
            	Messaging.SendMessage(succInform);
            }
            	
            if (this.successor != this.id) {
            	Message predInform = new Message(this.successor, this.id, -1, Integer.toString(this.id), -1, null, Type.NEW_PRED_INFORM);
            	Messaging.SendMessage(predInform);
            }
            
            hashtable = new Hashtable<Integer, String>();
            
            if (this.id > 0)
            	FindMyHash();
            
            Message message;
            
            for(;;){
            	message = ReceiveMessage();
            	if (!this.alive) {
            		message = new Message(this.predecessor, this.id, -1, Integer.toString(this.successor), -1, null, Type.NEW_SUCC_INFORM);
                	Messaging.SendMessage(message);
                	message = new Message(this.successor, this.id, -1, Integer.toString(this.predecessor), -1, hashtable, Type.NEW_PRED_INFORM);
                	Messaging.SendMessage(message);
        	        return;
            	}
            	MessageHandler messageHandler = new MessageHandler(message, this);
    	        messageHandler.start();
            }
            
        } catch (IOException | ClassNotFoundException | InterruptedException e) {
        	e.printStackTrace();
        }
    }
    
    public Message ReceiveMessage() throws ClassNotFoundException {
    	
    	Message message = null;
    	try {
    		
	    	Socket incoming = Server.accept();
	    	ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(incoming.getInputStream()));
	    	message = (Message) ois.readObject();
	        
    	} catch (IOException e) {
    		//e.printStackTrace();
		}  
    	return message;
    }
    
    public PredSucc FindPredSucc() {
    	
    	PredSucc predsucc = new PredSucc();
    	predsucc.predecessor = 0;
    	predsucc.successor = 0;
    	Message message = new Message(0, this.id, this.id, null, -1, null, Type.PRED_SUCC_REQUEST);
    	Messaging.SendMessage(message);
    	while (true) {

    		try {
				message = ReceiveMessage();
		        System.out.println(this.id + "\t: Message received from port-node " + message.getFrom() + " : " + message.getBody()); 
				predsucc.successor = Integer.parseInt(message.getBody());		
	    		if (predsucc.successor > this.id || predsucc.successor == 0)
	    			break;
	    		else {
	    			predsucc.predecessor = predsucc.successor;
	    			MessageHandler messageHandler = new MessageHandler(message, this);
					messageHandler.start();
	    		}
	    		
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}	
    	}
    	return predsucc;
    }
    
    public void FindMyHash() throws InterruptedException{
    	
    	Message msg = new Message(this.successor, this.id, this.id, null, -1, null, Type.REQUEST_HASH_TABLE);
    	Messaging.SendMessage(msg);
    	try {
			msg = ReceiveMessage();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
    	MessageHandler msgHandler = new MessageHandler(msg, this);
    	msgHandler.start();
    	msgHandler.join();
    	return;
    }
    
}