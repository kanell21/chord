package chord;

import java.util.Hashtable;
import java.util.Iterator;

public class MessageHandler extends Thread {
	
	private Message msg;
	
	private ChordNode node;
	
	public MessageHandler(Message msg, ChordNode node){
		this.msg = msg;
	    this.node = node;
	}	
	
	public void run() {
	
	        Type type = msg.getType();
	        Message message = null;
	        int hashKey;
	        
	        switch(type) {
	            case PRED_SUCC_REQUEST:
                    System.out.println(node.id + "\t: Received Message of type PRED_SUCC_REQUEST");
                    message = new Message(msg.getReplyTo(), node.id, -1, Integer.toString(node.successor), -1, null, Type.PRED_SUCC_REPLY);
                    Messaging.SendMessage(message);
                    break;
                    
                case PRED_SUCC_REPLY:
                	System.out.println(node.id + "\t: Received Message of type PRED_SUCC_REPLY");
                    message = new Message(Integer.parseInt(msg.getBody()), node.id, node.id, null, -1, null, Type.PRED_SUCC_REQUEST);
                    Messaging.SendMessage(message);
                    break;
                         
                case NEW_PRED_INFORM:
                	node.predecessor = Integer.parseInt(msg.getBody());
                	if (msg.getHashtable() != null) {
                		System.out.println(node.id + "\t: Received Message of type NEW_PRED_INFORM with Hashtable");
                		node.hashtable.putAll(msg.getHashtable());
                	}
                	else
                		System.out.println(node.id + "\t: Received Message of type NEW_PRED_INFORM");
                    break;
                
                case NEW_SUCC_INFORM:
                	System.out.println(node.id + "\t: Received Message of type NEW_SUCC_INFORM");
                	node.successor = Integer.parseInt(msg.getBody());
                    break;    
                
                case GRACEFUL_DEPARTURE:
                	System.out.println(node.id + "\t: Received Message of type GRACEFUL_DEPARTURE");
                	message = new Message(node.predecessor, node.id, -1, Integer.toString(node.successor), -1, null, Type.NEW_SUCC_INFORM);
                	Messaging.SendMessage(message);
                	message = new Message(node.successor, node.id, -1, Integer.toString(node.predecessor), -1, null, Type.NEW_PRED_INFORM);
                	Messaging.SendMessage(message);
                    break;
                
                case RECEIVE_HASH_TABLE:
                	System.out.println(node.id + "\t: Received Message of type RECEIVE_HASH_TABLE");
                	Hashtable<Integer,String> temp = msg.getHashtable();
                	node.hashtable.putAll(temp);
                    break;
                         
                case REQUEST_HASH_TABLE:
                	System.out.println(node.id + "\t: Received Message of type REQUEST_HASH_TABLE");
                	Hashtable<Integer,String> distribute_hash = new Hashtable<Integer,String>();
                	for (Iterator<Integer> iter = node.hashtable.keySet().iterator(); iter.hasNext(); ) {
                	    int key = (int) iter.next();
                	    if (key <= msg.getReplyTo()) {
                	    	distribute_hash.put(key,(String) node.hashtable.get(key));
                	    	node.hashtable.remove(key);            	    	
                	    }
                	}
                	message = new Message(msg.getReplyTo(), node.id, -1, null, -1, distribute_hash, Type.RECEIVE_HASH_TABLE);
                	Messaging.SendMessage(message);
                    break;
                
                case INSERT:
                	System.out.println(node.id + "\t: Received Message of type INSERT");
                	if (node.predecessor < msg.getHashKey() && (node.id >= msg.getHashKey() || node.id == 0)) {
                		System.out.println(node.id + "\t: Inserted hashkey-value: " + msg.getHashKey() + "-" + msg.getBody());
                		node.hashtable.put(msg.getHashKey(), msg.getBody());
                	}
                	else {
                		msg.setFrom(node.id);
                		msg.setTo(node.successor);
                		Messaging.SendMessage(msg);
                	}
                	break;
                
                case DELETE:
                	System.out.println(node.id + "\t: Received Message of type DELETE");
                	hashKey = msg.getHashKey();
                	if (node.predecessor < hashKey && (node.id > hashKey || node.id == 0)) {
                		if (node.hashtable.containsKey(hashKey)) {
                			node.hashtable.remove(hashKey);
                			System.out.println(node.id + "\t: Deleted hashkey-value: " + msg.getHashKey() + "-" + msg.getBody());
                		}
                		else
                			System.out.println(node.id + "\t: No hashkey "+ hashKey + " to delete");
                	}
                	else {
                		msg.setFrom(node.id);
                		msg.setTo(node.successor);
                		Messaging.SendMessage(msg);
                	}
                	break;
                	
                case QUERY:
                	System.out.println(node.id + "\t: Received Message of type QUERY");
                	hashKey = msg.getHashKey();
                	if (node.predecessor < hashKey && (node.id > hashKey || node.id == 0)) {
                		if (node.hashtable.containsKey(hashKey)) {
                			System.out.println(node.id + "\t: Returning hashkey-value: " + hashKey + "-" + msg.getBody());
                    		message = new Message(msg.getReplyTo(), node.id, -1, node.hashtable.get(msg.getHashKey()), hashKey, null, Type.RESPONSE);
                		}
                		else {
                			System.out.println(node.id + "\t: Nothing to return");
                    		message = new Message(msg.getReplyTo(), node.id, -1, null, -1, null, Type.RESPONSE);
                		}
                		Messaging.SendMessage(message);
                	}
                	else {
                		msg.setFrom(node.id);
                		msg.setTo(node.successor);
                		Messaging.SendMessage(msg);
                	}
                	break;
                	
                case QUERYALL:
                	if (node.id > 0) {
                		System.out.println(node.id + "\t: Received Message of type QUERYALL");
                		msg.getHashtable().putAll(node.hashtable);
                		msg.setTo(node.successor);
                		msg.setFrom(node.id);
                		Messaging.SendMessage(msg);
	        		}
                	else {
                		if (msg.getFrom() == -1) {
                			System.out.println(node.id + "\t: Received Message of type QUERYALL");
                			msg.setHashtable(new Hashtable<Integer, String>());
                			msg.getHashtable().putAll(node.hashtable);
                			msg.setTo(node.successor);
                			msg.setFrom(node.id);
                			Messaging.SendMessage(msg);
                		}
                		else {
                			System.out.println(node.id + "\t: Received QUERYALL response");
                			Hashtable<Integer, String> tmpHashtable = msg.getHashtable();
                			int key;
                			for (Iterator<Integer> iter = tmpHashtable.keySet().iterator(); iter.hasNext(); ) {
                				key = iter.next();
                				System.out.println(tmpHashtable.get(key));
                			}
                		}
                	}
                	break;
                	
                case RESPONSE:
                	System.out.println(node.id + "\t: Received Message of type RESPONSE with hashkey-value " + msg.getHashKey() + "-" + msg.getBody());
                	break;
                
                default:
                    System.out.println("Midweek days are so-so.");
                    break;
	        }
	        return;
	}

}
